#!/usr/bin/env python3
MAJOR = 0
MINOR = 6
PATCH = 0

VERSION = "{}.{}.{}".format(MAJOR, MINOR, PATCH)

